
<!-- Footer -->
<footer class="page-footer font-small" style="background-color: #294a70;height:9rem;">

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">
    <a href="" style="color: white;"> Copyright. All rights reserved.</a>
  </div>
   <div class="footer-copyright text-center py-3" style="color: white;">Copyright ©2020 . All rights reserved.
    <a href="" style="color: white;" >  | Developed By : |Innerwork Solutions Pvt.Ltd</a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->


<script type="text/javascript" src="script/script.js"></script>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"></script>

</body>


</html>