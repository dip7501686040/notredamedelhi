<?php require_once('header.php'); ?>
<style type="text/css">
	ol li{
		font-size: 22px;
	}
	h3{
		color: #3333ff;
	}
</style>
<div class="container">
	<h3 align="center">EXAMINATION AND PROMOTIONS</h3>
	<ol>
		<li>Students are prepared for the Central Board of Secondary Education Examination, Class X and Class XII.</li>
		<li>Regular tests are a feature. Attendance for these is compulsory and final result is declared on the cumulative marks obtained throughout the year. Hence, attendance for all tests and exams is essential. The Principal’s decision with regard to promotion is final.</li>
		<li>The pass mark is 40%.A student must pass in each of the subjects including non-academic subjects.</li>
		<li>The school has the semester system of evaluation and assessment.</li>
		<li>On the days when Unit Tests are held, attendance for the full day is essential. Students will not be permitted to take the Unit Test and return home. If the child is unwell he/she should stay at home. Parents should send their ward only if he/she can stay in school for the full day.</li>
		<li>Special arrangements cannot be made for pupils who for any reason whatsoever, are absent from the main examination or any part of it. Pupils, who are absent from any exam for whatever reason, will be awarded zero marks for that particular exam. (All fees due are to be paid before the commencement of the exams.)</li>
		<li>A student who uses unfair means during a test will be given zero marks for that subject. Repetition of the same will result in stern action like suspension or dismissal.</li>
		<li>Transfer certificates issued after the final examinations will state clearly that the student was promoted or not ready for the next class according to the actual result.</li>
		
	</ol>
</div>





<?php require_once('footer.php'); ?>
