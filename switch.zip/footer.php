<!-- Footer -->
<footer style="background-color: #13355e;">
     <div class="container py-5">
     <div class="row">
    <div class="col-md-6"><h3 style="color:white;">
    Notre Dame School
    </h3>
    <h6 style="color:white;">
    BTPS, Staff Colony, Badarpur, Delhi 110044, India
    </h6>
  
  </div>
    <div class="col-md-2">
     <a href="index.php" style="color:white;">Home </a> <br>
<a href="all_events.php" style="color:white;">Events </a>  <br>
<a href="contact.php" style="color:white;">Contact us</a><br>
<a href="https://nds.genericsoftware.in/Parent/login.aspx" style="color:white;">Parent Login</a><br>
<a href="<?php echo $Academic['alumni']  ?>" target="_new" style="color:white;">Alumni</a><br>

<br></div>
    <div class="col-md-4">
      <a href="https://www.facebook.com/notredamedelhi" target="_new"><img src="images/icon1.png" alt="" style="float: right;"></a>
      
    </div>
  </div>
     </div>
     <hr class="p-0 m-0 b-0">
     <div class="bg-light py-2">
         <div class="container text-center">
             <p class="text-muted mb-0 py-2">Copyright ©2020 . All rights reserved.</p>
         </div>
     </div>
 </footer>
<!-- Footer -->

<script type="text/javascript" src="script/calendar.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"></script>

</body>
</html>