}
else{
    echo "<script>window.location.href='admin_login.php'</script>";
}