<?php require_once('header.php');
$data=$_GET['data'];
?>
<center><embed src="documents/<?php echo $data; ?>" width="800px" height="2100px" /></center>


<?php require_once('footer.php'); ?>