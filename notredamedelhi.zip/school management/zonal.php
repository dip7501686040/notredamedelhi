<html>
<head>
<title>zonal page</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
	
	
			h2{
				color:#fc1c27;
				margin:10px;
				pading:10px;
				font-size:20px;
		
			}
			.main4{
				display:flex;
				margin:10px;
				padding:10px;
				//background-color:#d5e3dd;
				background:linear-gradient(to left,#dcf1f5,white);
			}
			.one{
				width:50%;
				height:97%;
				text-align:justify;
				font-size:20px;
				margin-right:20px;
			}
			.two{
				width:50%;
				height:97%;
				text-align:justify;
				font-size:20px;
				margin-right:20px;
			}
	
					.main5{
						display:flex;
						margin:10px;
						padding:10px;
						//background-color:#d5e3dd;
						background:linear-gradient(to left,#dcf1f5,white);
						}
					.three{
						width:35%;
						height:20%;
						text-align:justify;
						font-size:20px;
						margin-right:20px;
					}
					.three img{
						border:5px dashed gray;
						outline:2px solid gray;
					}
					.three img:hover{
						border:5px dashed gray;
						outline:2px solid gray;
						cursor:pointer;
						box-shadow:5px 5px 5px black;
						opacity:0.8;
					}
					
					.four{
						width:35%;
						height:20%;
						text-align:justify;
						font-size:20px;
						margin-right:20px;
					}
					.four img{
						border:5px dashed gray;
						outline:2px solid gray;
					}
					.four img:hover{
						border:5px dashed gray;
						outline:2px solid gray;
						cursor:pointer;
						box-shadow:5px 5px 5px black;
						opacity:0.8;
					}
					.five{
						width:30%;
						height:20%;
						text-align:justify;
						font-size:20px;
						margin-right:20px;
					}
					.five img{
						border:5px dashed gray;
						outline:2px solid gray;
					}
					.five img:hover{
						border:5px dashed gray;
						outline:2px solid gray;
						cursor:pointer;
						box-shadow:5px 5px 5px black;
						opacity:0.8;
					}
								.main6{
									display:flex;
									margin:10px;
									padding:10px;
									//background-color:#d5e3dd;
									background:linear-gradient(to left,#dcf1f5,white);
								}
								.six{
									width:35%;
									height:20%;
									text-align:justify;
									font-size:20px;
									margin-right:20px;
								}
								.six img{
									border:5px dashed gray;
									outline:2px solid gray;
								}
								.six img:hover{
									border:5px dashed gray;
									outline:2px solid gray;
									cursor:pointer;
									box-shadow:5px 5px 5px black;
									opacity:0.8;
								}
								.seven{
									width:35%;
									height:20%;
									text-align:justify;
									font-size:20px;
									margin-right:20px;
								}
								.seven img{
									border:5px dashed gray;
									outline:2px solid gray;
								}
								.seven img:hover{
									border:5px dashed gray;
									outline:2px solid gray;
									cursor:pointer;
									box-shadow:5px 5px 5px black;
									opacity:0.8;
								}
								.eight{
									width:30%;
									height:20%;
									text-align:justify;
									font-size:20px;
									margin-right:20px;
								}
								.eight img{
									border:5px dashed gray;
									outline:2px solid gray;
								}
								.eight img:hover{
									border:5px dashed gray;
									outline:2px solid gray;
									cursor:pointer;
									box-shadow:5px 5px 5px black;
									opacity:0.8;
								}


											@media (max-width: 768px){
											.main5{
												display:block;
												width:100%;
												height:auto;
												margin:0px;
												padding:0px;
											}
											
											.three{
												
												width:100%;
												height:auto;
												margin-bottom:2px;
											}
											.three img{
												
												width:100%;
												height:auto;
											}
											.four{
												
												width:100%;
												height:auto;
												margin-bottom:2px;
											}
											.four img{
												
												width:100%;
												height:auto;
											}
											.five{
												
												width:100%;
												height:auto;
												margin-bottom:2px;
											}
											.five img{
												
												width:100%;
												height:auto;
											}
											.main6{
												display:block;
												width:100%;
												height:auto;
												margin:0px;
												padding:0px;
											}
											
											.six{
												
												width:100%;
												height:auto;
												margin-bottom:2px;
											}
											.six img{
												
												width:100%;
												height:auto;
											}
											.seven{
												
												width:100%;
												height:auto;
												margin-bottom:2px;
											}
											.seven img{
												
												width:100%;
												height:auto;
											}
											.eight{
												
												width:100%;
												height:auto;
												margin-bottom:2px;
											}
											.eight img{
												
												width:100%;
												height:auto;
											}
											
											
											.main4{
												display:block;
												width:100%;
												height:auto;
												margin:0px;
												padding:0px;
											}
											h2{
												color:#fc1c27;
												
											}
											.one{
												
												width:auto;
												height:auto;
												margin-bottom:20px;
												margin-right:0px;
											}
											.two{
												
												width:auto;
												height:auto;
												margin-bottom:2px;
												margin-right:0px;
											}
											}
													@media (min-width: 769px) and (max-width: 1000px){
														.main4{
															width:950px;
															margin:0px;
														}
														
														.main5{
															width:950px;
															margin:0px;
														}
														.main6{
															width:950px;
															margin:0px;
														}
													
														}
											
				
	</style>
	

</head>
<body>
<h2>December 2018</h2>
	<div class="main4">
		<div class="one">
			<b style="color:#fc1c27;">ZONAL LEVEL HANDBALL CHAMPION</b> <br> <br>   

			<b>"Sports does not build character. They reveal it".</b><br><br>		

			The senior boys of Notre Dame School, with the help of their persistent training and efforts,
			participated in the South East District Zonal level Handball tournament and came back with the
			trophy in their hands! The gold medal winning team has made the school hold its head high in the 
			entire district.<br><br>
			<b style="color:#fc1c27;">Champions of South East District Sports Meet 2017-18</b>
		</div>
		
		<div class="two">
			<b style="color:#fc1c27;">ZONAL ATHLETIC MEET 2018</b><br>
			"Continuous effort - not strength or intelligence is the key to unlocking our potential". The Damians
			have proved this! The budding athletes of Notre Dame School made the school and their families proud 
			with their exceptional performances and the medals they received in the South East District Zonal Athletic
			Meet 2018 held at Thyagaraj Stadium."
		</div>
	</div>
	
	<div class="main5">
		<div class="three">
		<img src="1.jpg"><br><br>
			First Runner Up Jr. Boys Handball 
		</div>
		<div class="four">
		<img src="2.jpg"><br><br>
		    Overall Champions Athletics - Jr. Boys
		</div>
		<div class="five">
		<img src="3.jpg"><br><br>
			Overall Champions Athletics - Jr. Girls
		</div>
	</div>
	
	<div class="main6">
		<div class="six">
		<img src="4.jpg"><br><br>
			Overall Champions Athletics - Sub.Jr.Girls
		</div>
		<div class="seven">
		<img src="5.jpg"><br><br>
		    Overall Champions Athletics- Sub.Jr.Boys
		</div>
		<div class="eight">
		<img src="6.jpg"><br><br>
		  Overall Champions Athletics - Jr. Girls
		</div>
	</div>
</body>
</html>