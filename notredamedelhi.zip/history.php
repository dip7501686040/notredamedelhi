
<?php
require('header.php');
?>
<style>
h2{
		color:#072b52;
		margin:10px;
		padding:10px;
		font-size:20px;
		
	}
	.main1{
		display:flex;
		margin:10px;
		padding:10px;
	    background-color:#d5e3dd;
		background:linear-gradient(to left,#dcf1f5,white);
		text-align:justify;
		font-size:20px;
	}
</style>
<div class="container">

<div class="main1" >
The history of Notre Dame School, Badarpur begins with the invitation of NTPC, 
BTPS unit to start a project school for the children of their employees and the 
children of surrounding areas. Notre Dame School under the charismatic leadership 
of Sr. Mary Shobana and the able assistance of Sr. Mary Jaya and Sr. Mary Neelima began in 1990.<br><br>

Sister Mary Ranjita is honoured as the founding principal of Notre Dame School.
 During her tenure of ten years as principal, the school developed into a first rate 
 higher Secondary school, preparing students for the CBSE Examinations. The first batch 
 of students appeared for their Secondary examination in 1996 and after the up gradation, 
 the first batch of students appeared for their Senior Secondary examination in 2002.<br><br>

An overview of the history shows that during the past decades., the school has taken 
many giant strides with the collaborative efforts of devoted Principals, Sisters, Teachers,
 Parents and Well-wishers. As the School marches ahead to new heights of excellence, we keep 
 our focus on the motto of the school.
</div>
<br><br><br><br>
<h2>"GLORY TO GOD AND SERVICE TO ALL."</h2>
</div>


<?php
require('footer.php');
?>