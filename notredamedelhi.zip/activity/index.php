﻿<!DOCTYPE html> <html lang="en-US"><head>
	<meta name="google-site-verification" content="g1QZVht-LaGZgFSMafxdOAj3LzpVr9Q1K0ylWs9bJpw" />
	    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="https://notredamedelhi.com/xmlrpc.php">
    
<title>EVENTS</title>
<style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1580298830948{margin-top: 15px !important;}</style><meta name='robots' content='noindex,follow' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title=" &raquo; Feed" href="https://notredamedelhi.com/?feed=rss2" />
<link rel="alternate" type="application/rss+xml" title=" &raquo; Comments Feed" href="https://notredamedelhi.com/?feed=comments-rss2" />
<link rel="alternate" type="text/calendar" title=" &raquo; iCal Feed" href="https://notredamedelhi.com?post_type=tribe_events&#038;ical=1" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/notredamedelhi.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.2.7"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='tribe-common-skeleton-style-css'  href='https://notredamedelhi.com/wp-content/plugins/the-events-calendar/common/src/resources/css/common-skeleton.min.css?ver=4.11.2' type='text/css' media='all' />
<link rel='stylesheet' id='tribe-tooltip-css'  href='https://notredamedelhi.com/wp-content/plugins/the-events-calendar/common/src/resources/css/tooltip.min.css?ver=4.11.2' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-css'  href='https://notredamedelhi.com/wp-includes/css/dist/block-library/style.min.css?ver=5.2.7' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-theme-css'  href='https://notredamedelhi.com/wp-includes/css/dist/block-library/theme.min.css?ver=5.2.7' type='text/css' media='all' />
<link rel='stylesheet' id='ditty-news-ticker-font-css'  href='https://notredamedelhi.com/wp-content/plugins/ditty-news-ticker/inc/static/libs/fontastic/styles.css?ver=2.2.9' type='text/css' media='all' />
<link rel='stylesheet' id='ditty-news-ticker-css'  href='https://notredamedelhi.com/wp-content/plugins/ditty-news-ticker/inc/static/css/style.css?ver=1575875662' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='https://notredamedelhi.com/wp-content/plugins/revslider/public/assets/css/settings.css?ver=5.4.5.2' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='fullwidth-template-css'  href='https://notredamedelhi.com/wp-content/plugins/fullwidth-templates/assets/css/fullwidth-template.css?ver=5.2.7' type='text/css' media='all' />
<link rel='stylesheet' id='megamenu-css'  href='https://notredamedelhi.com/wp-content/uploads/maxmegamenu/style.css?ver=eb724a' type='text/css' media='all' />
<link rel='stylesheet' id='dashicons-css'  href='https://notredamedelhi.com/wp-includes/css/dashicons.min.css?ver=5.2.7' type='text/css' media='all' />
<link rel='stylesheet' id='fontawesome-css'  href='https://notredamedelhi.com/wp-content/themes/education-hub/third-party/font-awesome/css/font-awesome.min.css?ver=4.7.0' type='text/css' media='all' />
<link rel='stylesheet' id='education-hub-google-fonts-css'  href='//fonts.googleapis.com/css?family=Open+Sans%3A600%2C400%2C400italic%2C300%2C100%2C700%7CMerriweather+Sans%3A400%2C700&#038;ver=5.2.7' type='text/css' media='all' />
<link rel='stylesheet' id='education-hub-style-css'  href='https://notredamedelhi.com/wp-content/themes/education-hub/style.css?ver=5.2.7' type='text/css' media='all' />
<!--[if lt IE 9]>
<link rel='stylesheet' id='vc_lte_ie9-css'  href='https://notredamedelhi.com/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css?ver=6.0.5' type='text/css' media='screen' />
<![endif]-->
<link rel='stylesheet' id='js_composer_front-css'  href='https://notredamedelhi.com/wp-content/plugins/js_composer/assets/css/js_composer.min.css?ver=6.0.5' type='text/css' media='all' />
<script type='text/javascript' src='https://notredamedelhi.com/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp'></script>
<script type='text/javascript' src='https://notredamedelhi.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='https://notredamedelhi.com/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min.js?ver=5.4.5.2'></script>
<script type='text/javascript' src='https://notredamedelhi.com/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min.js?ver=5.4.5.2'></script>
<link rel='https://api.w.org/' href='https://notredamedelhi.com/index.php?rest_route=/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://notredamedelhi.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://notredamedelhi.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.2.7" />
<link rel="canonical" href="https://notredamedelhi.com/?page_id=1475" />
<link rel='shortlink' href='https://notredamedelhi.com/?p=1475' />
<link rel="alternate" type="application/json+oembed" href="https://notredamedelhi.com/index.php?rest_route=%2Foembed%2F1.0%2Fembed&#038;url=https%3A%2F%2Fnotredamedelhi.com%2F%3Fpage_id%3D1475" />
<link rel="alternate" type="text/xml+oembed" href="https://notredamedelhi.com/index.php?rest_route=%2Foembed%2F1.0%2Fembed&#038;url=https%3A%2F%2Fnotredamedelhi.com%2F%3Fpage_id%3D1475&#038;format=xml" />
<style>#mtphr-dnt-70 { color: #49688e; width: 104%; font-weight: bold; font-size: 20px; }</style><meta name="tec-api-version" content="v1"><meta name="tec-api-origin" content="https://notredamedelhi.com"><link rel="https://theeventscalendar.com/" href="https://notredamedelhi.com/index.php?rest_route=/tribe/events/v1/" /><meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<meta name="generator" content="Powered by Slider Revolution 5.4.5.2 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<script type="text/javascript">function setREVStartSize(e){

				try{ var i=jQuery(window).width(),t=9999,r=0,n=0,l=0,f=0,s=0,h=0;					

					if(e.responsiveLevels&&(jQuery.each(e.responsiveLevels,function(e,f){f>i&&(t=r=f,l=e),i>f&&f>r&&(r=f,n=e)}),t>r&&(l=n)),f=e.gridheight[l]||e.gridheight[0]||e.gridheight,s=e.gridwidth[l]||e.gridwidth[0]||e.gridwidth,h=i/s,h=h>1?1:h,f=Math.round(h*f),"fullscreen"==e.sliderLayout){var u=(e.c.width(),jQuery(window).height());if(void 0!=e.fullScreenOffsetContainer){var c=e.fullScreenOffsetContainer.split(",");if (c) jQuery.each(c,function(e,i){u=jQuery(i).length>0?u-jQuery(i).outerHeight(!0):u}),e.fullScreenOffset.split("%").length>1&&void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0?u-=jQuery(window).height()*parseInt(e.fullScreenOffset,0)/100:void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0&&(u-=parseInt(e.fullScreenOffset,0))}f=u}else void 0!=e.minHeight&&f<e.minHeight&&(f=e.minHeight);e.c.closest(".rev_slider_wrapper").css({height:f})					

				}catch(d){console.log("Failure at Presize of Slider:"+d)}

			};</script>
		<style type="text/css" id="wp-custom-css">
			.slider_23{
	margin-top:-23px;
}		</style>
		<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style type="text/css">/** Mega Menu CSS: fs **/</style>
</head>

<body class="page-template page-template-template-page-builder page-template-template-page-builder-php page page-id-1475 wp-custom-logo wp-embed-responsive tribe-no-js fpt-template fpt-template-education-hub mega-menu-primary site-layout-fluid global-layout-right-sidebar wpb-js-composer js-comp-ver-6.0.5 vc_responsive">

	    <!-- #site-navigation -->
      <?php include"header.php";  ?> <!-- #main-nav -->
    
	<div id="content" class="site-content"><div class="container"><div class="inner-wrapper">    <div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1580298830948" >
		<div class="wpb_wrapper">
			<p><strong style="color: red; font-weight: 900;">Goodbye Sir Jose</strong></p>
<p>Goodbyes are only for those who love with their eyes. Because, for those who love with their heart and soul, there is no such thing as separation! But for every beginning, there must be an end. It’s paradoxical but that’s how it is.</p>
<p><strong>On January 18, 2020,</strong> the entire Notre Dame family gathered to bid farewell to an exceptional teacher, an altruistic human being, Sir Jose. The beauty of the stage was enhanced by an aesthetically pleasing backdrop and the lamp waiting to be lighted. The amazing programme began with a prayer song and a prayer dance. The students were beautifully dressed and they presented a number of dance performances. Students presented some skits, followed by speeches appreciating the nature of Sir Jose.</p>
<p>This sense of humour and his dressing sense would be adamantly admired by everyone. He would be remembered by many students as a guide and mentor who helped shape their lives for the better. He is extremely charismatic and knew how to interact with his students on a personal level. He knew the art of adding charm to even the most boring lesson.</p>
<p>His finesse and his passion for literature gave him an unmatched ability to add life to mere fictional characters. The programme ended with a song by the choir, melodiously sung.</p>
<p>Lastly, Sir Jose expressed his feelings, his experiences and his journey in Notre Dame School after which Sr. Alice appreciated Sir and blessed the gathering. The day was great, filled with nostalgia, fun and excitement. Saying good bye is never easy. But, that is a bitter truth of life.</p>
<div class="entry-content">
<p><strong style="color: red; font-weight: 900;">Christmas Celebration</strong></p>
<p style="text-align: center;">                           “<strong>Joy to the world</strong></p>
<p><strong>                                                                              The Lord has come</strong>!”</p>
<p>Christmas is the festival which inspires the spirit if sharing and caring. Soaking in the spirit of Christmas, the students of Notre Dame School celebrated the festival of Christmas with enthusiasm on the <strong>21<sup>st</sup> of December 2019</strong>.</p>
<p>Leaving no stone unturned to sprinkle the magic of their love, the stage was wholly decorated by the students. The programme started with a prayer dance followed by a beautifully staged skit, directed by Sir Jose, depicting the significance of the festival, showcasing the life and journey of Jesus Christ.</p>
<p>The elements of energy and momentum could be witnessed in the children as they came forward and presented their items. Lastly the much awaited Santa Claus entered the stage with his elves and reindeers, boasting up the energy level of the students. A brief history of Santa Claus was depicted through dance and narrations. The programme ended with the choir singing melodious carols.</p>
<p>The Principal, Sr. Mary Alice threw light on the importance of the day and blessed the gathering with her inspirational words.</p>
</div>
<p>&nbsp;</p>
<p><a style="color: red; font-weight: 900;" title="Permalink to Pre-Primary Annual Day Report" href="index-1.htm?p=760" rel="bookmark">Graduation Ceremony and Farewell</a></p>
<p>“Twenty years from now you will be more disappointed by the things you didn’t do than by the ones you did do. So throw off the bowlines. Sail away from the safe harbour. Catch the trade winds in your sails. Explore, Dream, Discover.”</p>
<article id="post-760" class="post-760 post type-post status-publish format-standard hentry category-general">
<div class="entry-content">
<p><strong style="margin-left: 83%;">Mark Twain</strong></p>
<p><strong>On 17<sup>th</sup> of December 2019</strong>, the Senior classes were filled with enthusiasm as the Class XII1 students were to have their Graduation Ceremony and Farewell programme.</p>
<p>The Graduation Ceremony started with the lighting of the lamp and a melodious song by Sir Winston. The parents were made to sit in the auditorium. Sangeeta Ma’am addressed the gathering which was followed by the students sharing their 14 year experience in the school and thanking everyone who helped them in every possible way. Parents also expressed their gratitude towards the school for nurturing their kids.</p>
<p>The ceremony ended with the blessings of our Principal Sr. Mary Alice and distribution of mementos. The students, parents and teachers were given refreshments too.</p>
<p>All the students of Std. XI and XII looked gorgeous in their saris and suits. Class XI was very much excited to bid farewell to their seniors.<br />
The programme started with a comic skit followed by a good number of dance performances presented by Class XI.</p>
<p>There were some interesting titles which were given away and the most awaited and prestigious titles of “Miss Notre Dame” and “Mr. Notre Dame” were bagged by Sandra Simon of XII B and Soumya Ranjan Patnaik of XII A.<br />
The day ended with all the students enjoying themselves on the stage, dancing.</p>
</div>
<p>&nbsp;</p>
<p><strong style="color: red; font-weight: 900;">Pre-Primary Annual Day Report</strong><br />
On 26th November 2019 Pre-Primary Wing of the Notre Dame School celebrated its Annual Day.</p>
<p>The theme of the Annual Day was “Every drop Counts”.</p>
<p>Dressed up in vibrant colours, the tiny tots of Notre Dame School won the hearts of the parents and the guest of honours. The invitees were mesmerised by the confident performance of the little one who conveyed the beautiful message that every drop of water is precious. Hence forth we have to use it wisely and save it for the future generations to come.</p>
</article>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<header class="entry-header">
<p class="entry-title"><strong><a title="Permalink to Principals’s Day Celebration" href="http://www.notredamedelhi.com/activity/?p=757" rel="bookmark">Principals’s Day Celebration</a></strong></p>
</header>
<div class="entry-content">
<p>On <strong>23rd of November</strong>, Notre Dame campus looked awesome with children moving in costumes, the Principal’s office decorated with flowers, ribbons and balloons and the stage adorned with a lamp to be lit.</p>
<p>Principal Sr.Mary Alice and the Headmistress Sr.Mary Tanya were welcomed with much affection which could be seen in the eyes of the students. Sr.Mary Alice and Sr.Mary tanya were honoured with special prayer service by the Student Council members. An array of programme followed. Some dances, a qawwali performance, meaningful dance dance dramas, some words of appreciation , gifts, cards and bouquets were presented to the Sisters with reverence. The students expressed their love for the pillars of our school through their hard work which was seen in their performances.</p>
<p>The day ended with the blessings of our Sisters leaving their hearts filled with love and joy. the programme was a success</p>
</div>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<header class="entry-header">
<p class="entry-title"><strong><a title="Permalink to Children’s Day Celebration" href="http://www.notredamedelhi.com/activity/?p=752" rel="bookmark">Children’s Day Celebration</a></strong></p>
</header>
<div class="entry-content">
<p>“Children are not things to be moulded, but are people to be unfolded.” – Jess Lair</p>
<p>Children’s Day is celebrated to commemorate the birth anniversary of “Chacha Nehru”, the first Prime Minister of India.</p>
<p>This year as the pollution level crossed limits in Delhi, the schools were closed on the 14th of November. Therefore, Children’s day was celebrated on the <strong>20th of November</strong> in Notre Dame School, Badarpur.</p>
<p>The school glowed with the bright smiles of the children and the stage looked bright and beautiful as the teachers dressed up in attractive attires. The Children’s day programme began with a melodious song sung by the teachers, followed by a play staged in a very humorous manner which laid emphasis on the importance of education. The programme ended with a beautiful dance performance by the senior and the primary teachers and with the blessings of our Principal Sr.Mary Alice. The students were given some energizing refreshments in their respective classes. The day was a special and enjoyable one for all!!</p>
</div>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<header class="entry-header">
<p class="entry-title"><strong><a title="Permalink to STUDENT CULTURAL EXCHANGE PROGRAM 2019" href="http://www.notredamedelhi.com/activity/?p=746" rel="bookmark">STUDENT CULTURAL EXCHANGE PROGRAM 2019</a></strong></p>
</header>
<div class="entry-content">
<p>The student cultural program is an innovative initiative by the CBSE to promote healthy and amicable environment amongst students of two schools. It not only unites two school groups but also promotes friendship in an effective way to build bridges among students from different backgrounds.</p>
<p>Under this program Notre Dame School Badarpur and GBSSS No 1 Badarpur, had their cultural exchange on <strong>22October and 24 October 2019.</strong> On the 22nd , 30 boys from Notre Dame School visited GBSSS No1 Badarpur, where they were welcomed by the Principal, Staff and students with lot of warmth and affection. The students of both the schools exhibited their talent through skit, dance , mime and a patriotic song. Mr Shailender , Cluster Resource Centre Coordinator encouraged the students by his motivating speech and also taught a song to the students of both the schools. Students of both the schools interacted with each other and shared food amongst themselves.</p>
<p>In the second spell the gracious Notre Dame family received neighbouring school guests with lot of warmth and affection on the 24th of October 2019 by our school Principal Sr Mary Alice , staff members and other students with the school band which made it more special for them. As a tradition of Notre Dame School, the program started with a solemn prayer song and a welcome speech by the Principal. It was followed by patriotic song by the students of Notre Dame School. The guest school presented few cultural programs like action song, skits on social issues as ‘Beti Bachao Beti Padao Yojna’. They beautifully explained how education and employment of women is essential for the progress of our country. Students also discussed how plastic is damaging our environment. Few games were also organized in which children demonstrated exemplary spirit and had great fun. The students let their taste buds experience and relish the Indian delicacies with much taste and fun.</p>
<p>At the conclusion of the program, Mr B N Dubey , Cluster Coordinator blessed the gathering and appreciated the exchange program and was overwhelmed by the hospitality and participation of both the schools. As a token of love and to greet Diwali wishes, the host school presented handmade card and diyas to the guest students and teachers.<br />
The program was a milestone in our personal and professional journey of knowing each other. This report cannot be concluded without mentioning the unstinted support and involvement of : Mr B N Dubey, Mr Shailendar, Dr N P Sharma and Sr Mary Alice.<br />
We wish this relationship between Notre Dame and GBSSS No 1 Badarpur to grow from strength to strength with each passing year.</p>
</div>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<header class="entry-header">
<p class="entry-title"><strong><a title="Permalink to Seminar on Healthcare" href="http://www.notredamedelhi.com/activity/?p=727" rel="bookmark">Seminar on Healthcare</a></strong></p>
</header>
<div class="entry-content">
<p>“Let us receive all we need from the Lord of our Father” – St.Julie Billiart</p>
<p>On the 16th of September, (Dr).Sr.Mary Prema Raj educated the staff of Notre Dame on ‘Prevention and Proactive Healthcare’. She insisted on catch-em-young! from childhood good habits ought to become a part of growing up. She requested the staff to empower students with knowledge of health plan related activities and make them responsible human beings.</p>
<p>The staff elected members for the core committee and has started working to Practise, Promote and Propagate…. issues related to good health of mind and body!</p>
</div>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<header class="entry-header">
<p class="entry-title"><strong><a title="Permalink to Teachers Day Celebration" href="http://www.notredamedelhi.com/activity/?p=722" rel="bookmark">Teachers Day Celebration</a></strong></p>
</header>
<div class="entry-content">
<p>“I never dreamed of success, I worked for it” – Estee Lauder</p>
<p>On the 5th of September, 2019 Notre dame Campus lent an air of festivity as it was decked up for the most awaited Teachers day.</p>
<p>The morning started with a prayer service followed by an array of cultural programme, showcased by the students of the school.</p>
<p>Teachers were served refreshments and then they spent sometime interacting with students in the class rooms….chatting and dancing to their tunes for a change!</p>
<p>A grand a-la-Carte was arranged for the teachers. Prayers , bouquets and gifts followed.</p>
<p>Sr. Mary Shaija delivered a special message to the staff on the special occasion, while Sr.Mary Alice thanked the staff for all the support she experiences and blessed them in all their future endeavours!</p>
</div>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<div id="secondary" class="widget-area" role="complementary">
<aside id="search-2" class="widget widget_search">
<form id="searchform" role="search" action="../" method="get">
<div><label class="screen-reader-text" for="s">Search for:</label><br />
<input id="s" name="s" type="text" value="" /></div>
<div></div>
<div><input id="searchsubmit" style="/* margin-left: 5%; */ margin-top: 5%;" type="submit" value="Search" /></div>
</form>
</aside>
<aside id="archives-2" class="widget widget_archive">
<p class="widget-title"><strong>Archives</strong></p>
<ul>
		<li><a href='index-113.htm?m=201912' title='dec 2019'>December 2019</a></li>
			<li><a href='index-14.htm?m=201911' title='November 2019'>November 2019</a></li>
	<li><a href='#' title='October 2019'>October 2019</a></li>
	<li><a href='#' title='September 2019'>September 2019</a></li>
	<li><a href='#' title='August 2019'>August 2019</a></li>
	<li><a href='#' title='August 2019'>July 2019</a></li>
	<li><a href='#' title='May 2019'>May 2019</a></li>
	<li><a href='#' title='April 2019'>April 2019</a></li>
	
	<li><a href='#' title='August 2018'>August 2018</a></li>
	<li><a href='#' title='July 2018'>July 2018</a></li>
	<li><a href='#' title='May 2018'>May 2018</a></li>
	<li><a href='#' title='April 2018'>April 2018</a></li>
	<li><a href='#' title='March 2018'>March 2018</a></li>
	<li><a href='#' title='February 2018'>February 2018</a></li>
	<li><a href='#' title='January 2018'>January 2018</a></li>
	<li><a href='#' title='September 2017'>September 2017</a></li>
	<li><a href='#' title='August 2017'>August 2017</a></li>
	<li><a href='#' title='May 2017'>May 2017</a></li>
	<li><a href='#' title='April 2017'>April 2017</a></li>
	<li><a href='#' title='February 2017'>February 2017</a></li>
	<li><a href='#' title='December 2016'>December 2016</a></li>
	<li><a href='#' title='November 2016'>November 2016</a></li>
	<li><a href='#' title='October 2016'>October 2016</a></li>
	<li><a href='#' title='September 2016'>September 2016</a></li>
	<li><a href='#' title='August 2016'>August 2016</a></li>
	<li><a href='#' title='July 2016'>July 2016</a></li>
	<li><a href='#' title='May 2016'>May 2016</a></li>
	<li><a href='#' title='February 2016'>February 2016</a></li>
	<li><a href='#' title='December 2015'>December 2015</a></li>
	
	<li><a href='#?m=201504' title='April 2015'>April 2015</a></li>
	<li><a href='#?m=201502' title='February 2015'>February 2015</a></li>
	<li><a href='#?m=201412' title='December 2014'>December 2014</a></li>
	<li><a href='#?m=201411' title='November 2014'>November 2014</a></li>
	<li><a href='#?m=201409' title='September 2014'>September 2014</a></li>
	<li><a href='#?m=201408' title='August 2014'>August 2014</a></li>
	<li><a href='#?m=201407' title='July 2014'>July 2014</a></li>
	<li><a href='#?m=201406' title='June 2014'>June 2014</a></li>
	<li><a href='#?m=201404' title='April 2014'>April 2014</a></li>
	<li><a href='#?m=201402' title='February 2014'>February 2014</a></li>
	<li><a href='#?m=201401' title='January 2014'>January 2014</a></li>
	<li><a href='#?m=201312' title='December 2013'>December 2013</a></li>
	<li><a href='#?m=201310' title='October 2013'>October 2013</a></li>
	<li><a href='#?m=201309' title='September 2013'>September 2013</a></li>
	<li><a href='#?m=201308' title='August 2013'>August 2013</a></li>
	<li><a href='#?m=201305' title='July 2013'>July 2013</a></li>
	<li><a href='#?m=201305' title='May 2013'>May 2013</a></li>
		</ul>
</aside>
</div>
<p><!-- #secondary --><!-- #main .wrapper --></p>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<header class="entry-header">
<p class="entry-title"><strong><a title="Permalink to Health and Physical Education (HPE) SEWA by Std.XI" href="/activity/?p=739" rel="bookmark">Health and Physical Education (HPE) SEWA by Std.XI</a></strong></p>
</header>
<div class="entry-content">
<p>On <strong>September 7, 2019</strong> students of XI B took part in a day’s activities of an NGO named ‘Jansharnam’ in Molarband extension. This NGO is taken care of by Mr.Ramanshu Verma and his team which consists of six teachers.</p>
<p>Students of Class XI B presented a cultural programme for 140 children. They sang songs, discussed with children about their problems and motivated them to continue their studies. The children of the ‘Jansharnam’ also showcased their talents. Students distributed notebooks, clothes and had sweets together.</p>
<p>Notre Dame school students took this service under the guidelines of CBSE HPE programme. It was an enriching visit for the students, mentors, children and the ladies of the NGO.</p>
</div>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<header class="entry-header">
<p class="entry-title"><strong><a title="Permalink to Seminar by Sr.Mary Alice" href="http://www.notredamedelhi.com/activity/?p=733" rel="bookmark">Seminar by Sr.Mary Alice</a></strong></p>
</header>
<div class="entry-content">
<p>“Let yourself be drawn by the stronger pull of that which you truly love” – Rumi</p>
<p>On the<strong> 28th of September,</strong> as the staff stood on the threshold of a new semester, Sr.Mary Alice (Principal) reminded the teachers of the noble profession or say vocation they are into.</p>
<p>She recommended innumerable ways in which the staff could actually improve, motivate and bring out the best in the students.</p>
</div>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<header class="entry-header">
<p class="entry-title"><strong><a title="Permalink to Class room Management" href="http://www.notredamedelhi.com/activity/?p=730" rel="bookmark">Class room Management</a></strong></p>
</header>
<div class="entry-content">
<p>Resource person – Mrs.Kavita Iyer</p>
<p>“I never dreamed about success, I worked for it”- Estee Lauder</p>
<p>Methods very logical, practical and pragmatic was shared by Ms.Kavita Iyer from Orient Black Swan Publication on classroom management.</p>
<p>She emphasized on managing learners, resources and the room(space). Her inputs were then implemented in the class room by the staff and found it to be very suitable. Critical thinking, technology and other life skills has now become a part of everyday teaching. Students now seem to be enjoying their lessons!</p>
<p><strong>Thanks to Mrs.Kavita Iyer!</strong></p>
</div>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<article id="post-717" class="post-717 post type-post status-publish format-standard hentry category-general">
<header class="entry-header">
<p class="entry-title"><a title="Permalink to Student Council 2019-2020" href="http://www.notredamedelhi.com/activity/?p=717" rel="bookmark">Student Council 2019-2020</a></p>
</header>
<p><!-- .entry-header --></p>
<div class="entry-content">
<p>“Ride the energy of your own unique spirit” – G.Roth</p>
<p>President : Aadhya Singh<br />
Vice President : Sumit Yadav<br />
Secretary : Sakshi Bhatt<br />
Cultural Secretary : Ishika Sharma<br />
Sports Captain : Vanshika Rawat</p>
<p><u>Executive Members</u><br />
Khushnuma<br />
Tripti Bhardwaj</p>
<p><span style="color: blue;">Gandhi House</span><br />
Captian : Manvi Sharma<br />
Vice Captain : Jiya Rexwal</p>
<p><span style="color: green;">Tagore House</span><br />
Captain : Divyanshi<br />
Vice Captain : Divya Thapliyal</p>
<p><span style="color: red;">Sarojini House</span><br />
Captain : Diksha Kaushaik<br />
Vice Captain : Astha</p>
<p><span style="color: red;">Vivekanada House</span><br />
Captain : Nimisha Bhardwaj<br />
Vice Captain : Jiya Singh</p>
<p>KUDOS AND CONGRATULATIONS TO ONE AND ALL!</p>
</div>
</article>

		</div>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			
		</div>
	</div>
</div></div></div></div>
</div><!-- .inner-wrapper --></div><!-- .container --></div><!-- #content -->
	<!-- #colophon -->
</div><!-- #page --><a href="#page" class="scrollup" id="btn-scrollup"><i class="fa fa-chevron-up"></i></a>
		<script>
		( function ( body ) {
			'use strict';
			body.className = body.className.replace( /\btribe-no-js\b/, 'tribe-js' );
		} )( document.body );
		</script>
		<script> /* <![CDATA[ */var tribe_l10n_datatables = {"aria":{"sort_ascending":": activate to sort column ascending","sort_descending":": activate to sort column descending"},"length_menu":"Show _MENU_ entries","empty_table":"No data available in table","info":"Showing _START_ to _END_ of _TOTAL_ entries","info_empty":"Showing 0 to 0 of 0 entries","info_filtered":"(filtered from _MAX_ total entries)","zero_records":"No matching records found","search":"Search:","all_selected_text":"All items on this page were selected. ","select_all_link":"Select all pages","clear_selection":"Clear Selection.","pagination":{"all":"All","next":"Next","previous":"Previous"},"select":{"rows":{"0":"","_":": Selected %d rows","1":": Selected 1 row"}},"datepicker":{"dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesMin":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"nextText":"Next","prevText":"Prev","currentText":"Today","closeText":"Done","today":"Today","clear":"Clear"}};/* ]]> */ </script><script type='text/javascript' src='https://notredamedelhi.com/wp-content/plugins/ditty-news-ticker/inc/static/js/jquery.touchSwipe.min.js?ver=2.2.9'></script>
<script type='text/javascript' src='https://notredamedelhi.com/wp-content/plugins/ditty-news-ticker/inc/static/js/jquery.easing.js?ver=1.4.1'></script>
<script type='text/javascript' src='https://notredamedelhi.com/wp-content/plugins/ditty-news-ticker/inc/static/js/imagesloaded.pkgd.min.js?ver=4.1.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var mtphr_dnt_vars = {"is_rtl":""};
/* ]]> */
</script>
<script type='text/javascript' src='https://notredamedelhi.com/wp-content/plugins/ditty-news-ticker/inc/static/js/ditty-news-ticker.min.js?ver=1575875662'></script>
<script type='text/javascript' src='https://notredamedelhi.com/wp-content/themes/education-hub/js/skip-link-focus-fix.min.js?ver=20130115'></script>
<script type='text/javascript' src='https://notredamedelhi.com/wp-content/themes/education-hub/third-party/cycle2/js/jquery.cycle2.min.js?ver=2.1.6'></script>
<script type='text/javascript' src='https://notredamedelhi.com/wp-content/themes/education-hub/js/custom.min.js?ver=1.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var EducationHubScreenReaderText = {"expand":"<span class=\"screen-reader-text\">expand child menu<\/span>","collapse":"<span class=\"screen-reader-text\">collapse child menu<\/span>"};
/* ]]> */
</script>
<script type='text/javascript' src='https://notredamedelhi.com/wp-content/themes/education-hub/js/navigation.min.js?ver=20120206'></script>
<script type='text/javascript' src='https://notredamedelhi.com/wp-includes/js/hoverIntent.min.js?ver=1.8.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var megamenu = {"timeout":"300","interval":"100"};
/* ]]> */
</script>
<script type='text/javascript' src='https://notredamedelhi.com/wp-content/plugins/megamenu/js/maxmegamenu.js?ver=2.7.3'></script>
<script type='text/javascript' src='https://notredamedelhi.com/wp-includes/js/wp-embed.min.js?ver=5.2.7'></script>
<script type='text/javascript' src='https://notredamedelhi.com/wp-content/plugins/js_composer/assets/js/dist/js_composer_front.min.js?ver=6.0.5'></script>
<?php require_once("../footer.php");  ?>
</body>
</html>
