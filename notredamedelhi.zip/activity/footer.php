<footer id="colophon" role="contentinfo">
		<div class="site-info">
						<div class="copyright"><a href="innerworkindia.com" target="_blank"><font color="#7b0404"><b>innerwork</b></font></a> | <a href="https://www.facebook.com/manzar.hussain" target="_blank">Designed by <font color="#3300FF"><u><b>innerwork team</b></u></font></a> | <a href="..\admin.html"><font color="#3300FF"><u>Admin Panel</u></font></a>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="..\index.html" title="">Home</a> &nbsp;&nbsp;
                <a href="..\admissions.html" title="">Admissions</a> &nbsp;&nbsp;
                <a href="..\faculty.html" title="">Faculty</a> &nbsp;&nbsp;
                <a href="..\objective.html" title="">Objective</a> &nbsp;&nbsp;
                <a href="" title="">Gallery</a> &nbsp;&nbsp;
                <a href="..\about.html" title="">About</a> &nbsp;&nbsp;
                <a href="..\contact1.html" title="">Contact</a> 
		
</div>
</div><!-- .site-info -->
                                           
            
	</footer><!-- #colophon -->
