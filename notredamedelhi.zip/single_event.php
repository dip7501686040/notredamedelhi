<?php  require_once('header.php'); ?>

<br>
<div class="container">
<div class="row">
    <div class="col-sm-8">
    <div class="card">
  <div class="card-header">
   12 July 2020
  </div>
  <div class="card-body">
    <h5 class="card-title">Teacher's Day</h5>
    
    <img src="images/main.jpeg" alt="main" class="img-thumbnail" style="height: 15em;float:right;">
    <p class="card-text">The world is the Earth and all life on it, including human civilisation.[1] In a philosophical context, the "world" is the whole of the physical Universe, or an ontological world (the "world" of an individual). In a theological context, the world is the material or the profane sphere, as opposed to the celestial, spiritual, transcendent or sacred spheres. "End of the world" scenarios refer to the end of human history, often in religious contexts.

The history of the world is commonly understood as the history of humanity spanning the major geopolitical developments of about five millennia, from the first civilisation to the present. In terms such as world religion, world language, world government, and world war, the term world suggests an international or intercontinental scope without necessarily implying participation of every part of the world.

The world population is the sum of all human populations at any time; similarly, the world economy is the sum of the economies of all societies or countries, especially in the context of globalisation. Terms such as "world championship", "gross world product", and "world flags" imply the sum or combination of all sovereign states.</p>
    
  </div>
</div>
    </div>
    <div class="col-sm-4">
    <ul class="list-group">
  <li class="list-group-item active" style="background-color: #13355e;color:white;"><b>Archives</b></li>
  <li class="list-group-item"><a href="" style="color:red;">Dapibus ac facilisis in</a></li>
  <li class="list-group-item"><a href="" style="color:red;">Dapibus ac facilisis in</a></li>
  <li class="list-group-item"><a href="" style="color:red;">Dapibus ac facilisis in</a></li>
  <li class="list-group-item"><a href="" style="color:red;">Dapibus ac facilisis in</a></li>
</ul>
    </div>
  </div>
</div>

<br>
<?php  require_once('footer.php'); ?>