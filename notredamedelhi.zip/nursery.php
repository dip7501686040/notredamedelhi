<?php
require_once('header.php');
?>
<!--......body........-->



<?php
require_once('footer.php');
?>