<?php
require_once('header.php');
?>
<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
th, td {
  padding: 5px;
  text-align: left;
}
</style>
<div class="container">
    <div class="row">
    <table style="width:100%">
  <tr>
    <th>Name of the school with address :</th>
    <td>Notre Dame School, B.T.P.S  Staff Colony Badarpur P.O

New Delhi-110044</td>
  </tr>
  <tr>
    <th>(i) E-mail  :</th>
    <td>notredameschoolbadarpur@gmail.com</td>
  </tr>
  <tr>
    <th>(ii) Phone No.:</th>
    <td>011-26948713 ,011-29942349</td>
  </tr>
  <tr>
    <th>Year of establishment of school:</th>
    <td>1990</td>
  </tr>
  <tr>
    <th>(ii) Phone No.:</th>
    <td>011-26948713 ,011-29942349</td>
  </tr>
</table>
    </div>

</div>

<?php
require_once('footer.php');
?>