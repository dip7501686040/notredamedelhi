
<?php
require('header.php');
?>
<link rel="stylesheet" type="text/css" href="css/first.css">



<h6>EXAMINATIONS AND PROMOTIONS</h5><br>

<!--------------content--------------->
<div class="container" id="di">
	<p>1. Student are prepared for the central board of secondary education examinatrion. Class X and class XII.</p>
	
	<p>
	2. Regular test are a feature. Attendence for these is compulsory and final result is declared on the cumulative marks obtained throughout the year. Hence attendence for all tests and exam is essential. the principal's decision with regard to promotion is final.
	</p>

	<p>
	3. The pass mark is 40%. A student must pass in each of the subject including non-academic subjects.
	</p>

	<p>
	4. The school has the semester system of evaluation and assessment.
	</p>

	<p>
	5. On the days when unit test are held, attendence for the full day is essential. Student will not be permitted to take the unit test and return home. if the child is unwell he/she should stay at home.parent should send their ward only if he/she can stay in school for the full day.
	</p>

	<p>
	6. Special arrangement can not be made for pupils who for any reason whatsoever, are absent from the main examination or any part of it. pupils who are absent from any exam for whatever reason, will be awarded zero marks for that particular exam.(all fees due are to be paid before the commencement of the exams). 
	</p>

	<p>
	7. A student who uses unfair means during a test will be given zero marks for that subject.Repetition of the same will result in stern action like suspension or dismissal.
	</p>

	<p>
	8. Transfer certificate issued after the final examination will state clearly that th student was promoted or not ready for the next class according to the actual result.
	</p>

</div> 

<!--------------footer--------------->

<?php
require('footer.php');
?>